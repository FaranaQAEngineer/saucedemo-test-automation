# SauceDemo Automation Framework
## Selenium + TestNG + POM + ExtentReports

---

## 📁 Project Structure

```
SauceDemo-Automation/
│
├── src/
│   ├── main/java/com/saucedemo/
│   │   ├── config/
│   │   │   └── ConfigReader.java          ← Reads config.properties
│   │   ├── pages/
│   │   │   ├── LoginPage.java             ← Login page locators & actions
│   │   │   ├── HomePage.java              ← Products page locators & actions
│   │   │   ├── CartPage.java              ← Cart page locators & actions
│   │   │   └── CheckoutPage.java          ← Checkout + Confirmation page
│   │   └── utils/
│   │       ├── DriverFactory.java         ← WebDriver setup & teardown
│   │       ├── ExtentReportManager.java   ← HTML Report generation
│   │       └── BaseTest.java              ← Parent class for all tests
│   │
│   └── test/
│       ├── java/com/saucedemo/tests/
│       │   ├── LoginTest.java             ← Login & Logout test cases
│       │   ├── ProductTest.java           ← Product Search test cases
│       │   ├── CartTest.java              ← Add/Remove Cart test cases
│       │   └── CheckoutTest.java          ← Checkout & Confirmation tests
│       └── resources/
│           └── config.properties          ← URL, browser, credentials
│
├── reports/                               ← HTML reports generated here
├── pom.xml                                ← Maven dependencies
├── testng.xml                             ← TestNG suite config
└── README.md
```

---

## ✅ Modules Covered

| Module              | Test Class        | Test Cases |
|---------------------|-------------------|------------|
| Login               | LoginTest.java    | TC_LOGIN_01 to TC_LOGIN_04 |
| Logout              | LoginTest.java    | TC_LOGIN_05 |
| Product Search      | ProductTest.java  | TC_PRODUCT_01 to TC_PRODUCT_03 |
| Add to Cart         | CartTest.java     | TC_CART_01, TC_CART_02 |
| Remove from Cart    | CartTest.java     | TC_CART_03 |
| Checkout            | CheckoutTest.java | TC_CHECKOUT_01 to TC_CHECKOUT_03 |
| Order Confirmation  | CheckoutTest.java | TC_CHECKOUT_04 (Full E2E) |

---

## 🛠️ Prerequisites

Make sure these are installed on your system:

| Tool | Version | Download |
|------|---------|----------|
| Java JDK | 11 or above | https://adoptium.net/ |
| Maven | 3.6 or above | https://maven.apache.org/download.cgi |
| Google Chrome | Latest | https://www.google.com/chrome/ |
| IntelliJ IDEA (recommended) | Any | https://www.jetbrains.com/idea/ |

---

## 🚀 Steps to Run the Project

### Step 1: Clone or Extract the Project
If you received a ZIP file, extract it to a folder like:
```
C:\Projects\SauceDemo-Automation
```

### Step 2: Open in IntelliJ IDEA
1. Open IntelliJ IDEA
2. Click **File → Open**
3. Select the `SauceDemo-Automation` folder
4. Wait for Maven to download dependencies (you'll see progress in the bottom bar)

### Step 3: Verify config.properties
Open `src/test/resources/config.properties` and confirm:
```properties
url=https://www.saucedemo.com
browser=chrome
valid.username=standard_user
valid.password=secret_sauce
locked.username=locked_out_user
```

### Step 4: Run All Tests via Maven (Command Line)

Open a terminal/command prompt and navigate to the project folder:
```bash
cd C:\Projects\SauceDemo-Automation
```

Run all tests:
```bash
mvn clean test
```

### Step 5: Run via TestNG XML (IntelliJ)
1. Right-click on `testng.xml`
2. Select **Run 'testng.xml'**

### Step 6: Run a Single Test Class
Right-click on any test file (e.g., `LoginTest.java`) → **Run 'LoginTest'**

---

## 📊 View Test Reports

After running, HTML reports are generated in:
```
reports/SauceDemo_Report_<timestamp>.html
```

Open this file in any browser to view:
- Pass/Fail status for each test
- Step-by-step logs
- Screenshots on failure
- System info (browser, URL, framework)

---

## 🔧 Configuration Options

### Run in Headless Mode (no browser window - for CI/CD)
Open `DriverFactory.java` and uncomment this line:
```java
// options.addArguments("--headless");
```

### Change Browser to Firefox
In `config.properties`:
```properties
browser=firefox
```

---

## 📝 Framework Design Patterns Used

| Pattern | Where Used |
|---------|-----------|
| **Page Object Model (POM)** | `pages/` package |
| **Factory Pattern** | `DriverFactory.java` |
| **Singleton Pattern** | `ExtentReportManager.java` |
| **ThreadLocal** | Parallel execution support in `DriverFactory` |
| **Data-driven** | `config.properties` + `ConfigReader` |

---

## ❓ Common Issues

| Issue | Solution |
|-------|----------|
| `ChromeDriver not found` | WebDriverManager handles this automatically |
| `config.properties not found` | Run Maven from the project root directory |
| `Tests not running` | Right-click `testng.xml` → Run |
| `Browser not opening` | Ensure Chrome is installed and up to date |
