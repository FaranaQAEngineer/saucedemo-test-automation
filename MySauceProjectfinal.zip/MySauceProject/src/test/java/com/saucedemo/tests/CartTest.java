package com.saucedemo.tests;

import com.aventstack.extentreports.Status;
import com.saucedemo.config.ConfigReader;
import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.HomePage;
import com.saucedemo.pages.LoginPage;
import com.saucedemo.utils.BaseTest;
import com.saucedemo.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CartTest extends BaseTest {

    @Test(priority = 1, description = "TC_CART_01 - Add product to cart and verify badge count")
    public void testAddProductToCart() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CART_01: Add Product to Cart");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Home page not loaded");

        String productName = homePage.getFirstProductName();
        sleep(500);
        homePage.addFirstProductToCart();
        sleep(1000);
        ExtentReportManager.getExtentTest().log(Status.INFO, "Added: " + productName);

        int cartCount = homePage.getCartCount();
        Assert.assertEquals(cartCount, 1, "Expected 1 in cart, got: " + cartCount);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CART_01 PASSED");
    }

    @Test(priority = 2, description = "TC_CART_02 - Verify product appears in cart page")
    public void testProductAppearsInCart() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CART_02: Product in Cart Page");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);
        CartPage cartPage = new CartPage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Home page not loaded");

        String addedProductName = homePage.getFirstProductName();
        homePage.addFirstProductToCart();
        sleep(1000);

        homePage.clickCartIcon();
        sleep(1500);
        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page not displayed");

        String cartItemName = cartPage.getFirstCartItemName();
        Assert.assertEquals(cartItemName, addedProductName,
                "Cart item mismatch. Expected: " + addedProductName + " | Got: " + cartItemName);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CART_02 PASSED: " + cartItemName);
    }

    @Test(priority = 3, description = "TC_CART_03 - Remove item from cart")
    public void testRemoveItemFromCart() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CART_03: Remove Item from Cart");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);
        CartPage cartPage = new CartPage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Home page not loaded");

        homePage.addFirstProductToCart();
        sleep(1000);
        Assert.assertEquals(homePage.getCartCount(), 1, "Cart count not 1");

        homePage.clickCartIcon();
        sleep(1500);
        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page not loaded");

        cartPage.removeFirstItem();
        sleep(1000);

        boolean isEmpty = cartPage.isCartEmpty();
        Assert.assertTrue(isEmpty, "Cart NOT empty after remove");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CART_03 PASSED: Cart empty");
    }
}