package com.saucedemo.tests;

import com.aventstack.extentreports.Status;
import com.saucedemo.config.ConfigReader;
import com.saucedemo.pages.HomePage;
import com.saucedemo.pages.LoginPage;
import com.saucedemo.utils.BaseTest;
import com.saucedemo.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductTest extends BaseTest {

    private void loginToApp() {
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Login failed");
    }

    @Test(priority = 1, description = "TC_PRODUCT_01 - Verify products displayed on home page")
    public void testProductsDisplayed() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_PRODUCT_01: Verify products displayed");
        loginToApp();

        HomePage homePage = new HomePage(driver);
        int productCount = homePage.getProductCount();
        ExtentReportManager.getExtentTest().log(Status.INFO, "Products found: " + productCount);

        Assert.assertTrue(productCount > 0, "No products displayed");
        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_PRODUCT_01 PASSED: " + productCount + " products");
    }

    @Test(priority = 2, description = "TC_PRODUCT_02 - Search product by name")
    public void testSearchProductByName() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_PRODUCT_02: Search product");
        loginToApp();
        sleep(500);

        HomePage homePage = new HomePage(driver);
        boolean found = homePage.searchProductByName("Sauce Labs Backpack");
        Assert.assertTrue(found, "Product 'Sauce Labs Backpack' not found");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_PRODUCT_02 PASSED: Product found");
    }

    @Test(priority = 3, description = "TC_PRODUCT_03 - First product name not empty")
    public void testFirstProductNameNotEmpty() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_PRODUCT_03: First product name check");
        loginToApp();
        sleep(500);

        HomePage homePage = new HomePage(driver);
        String firstName = homePage.getFirstProductName();
        Assert.assertNotNull(firstName, "First product name is null");
        Assert.assertFalse(firstName.isEmpty(), "First product name is empty");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_PRODUCT_03 PASSED: " + firstName);
    }
}