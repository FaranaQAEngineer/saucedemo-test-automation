package com.saucedemo.tests;

import com.aventstack.extentreports.Status;
import com.saucedemo.config.ConfigReader;
import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.CheckoutPage;
import com.saucedemo.pages.HomePage;
import com.saucedemo.pages.LoginPage;
import com.saucedemo.utils.BaseTest;
import com.saucedemo.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest {

    private void loginAndAddToCart() {
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Home page not loaded");
        homePage.addFirstProductToCart();
        sleep(1000);
        Assert.assertEquals(homePage.getCartCount(), 1, "Product not added to cart");
        homePage.clickCartIcon();
        sleep(1500);
    }

    @Test(priority = 1, description = "TC_CHECKOUT_01 - Navigate from Cart to Checkout page")
    public void testNavigateToCheckout() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CHECKOUT_01: Navigate to Checkout");

        loginAndAddToCart();
        CartPage cartPage = new CartPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page not displayed");
        cartPage.clickCheckout();
        sleep(1500);

        Assert.assertTrue(checkoutPage.isCheckoutStepOneDisplayed(), "Checkout Step One not shown");
        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CHECKOUT_01 PASSED");
    }

    @Test(priority = 2, description = "TC_CHECKOUT_02 - Complete checkout with valid info")
    public void testCompleteCheckout() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CHECKOUT_02: Complete Checkout");

        loginAndAddToCart();
        CartPage cartPage = new CartPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        cartPage.clickCheckout();
        sleep(1500);
        Assert.assertTrue(checkoutPage.isCheckoutStepOneDisplayed(), "Checkout not shown");

        checkoutPage.fillCheckoutInfo("Rahul", "Sharma", "400601");
        sleep(800);
        checkoutPage.clickContinue();
        sleep(1500);

        Assert.assertTrue(checkoutPage.isCheckoutOverviewDisplayed(), "Overview not shown");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Total: " + checkoutPage.getTotalPriceText());
        sleep(1000);

        checkoutPage.clickFinish();
        sleep(2000);

        Assert.assertTrue(checkoutPage.isOrderConfirmationDisplayed(), "Confirmation not shown");
        String header = checkoutPage.getConfirmationHeader();
        Assert.assertEquals(header, "Thank you for your order!", "Wrong header: " + header);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CHECKOUT_02 PASSED: " + header);
    }

    @Test(priority = 3, description = "TC_CHECKOUT_03 - Checkout with empty fields shows error")
    public void testCheckoutWithEmptyFields() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CHECKOUT_03: Empty Fields Error");

        loginAndAddToCart();
        CartPage cartPage = new CartPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        cartPage.clickCheckout();
        sleep(1500);
        Assert.assertTrue(checkoutPage.isCheckoutStepOneDisplayed(), "Checkout not shown");

        checkoutPage.clickContinue();
        sleep(1000);

        Assert.assertTrue(checkoutPage.isErrorDisplayed(), "Error NOT shown for empty fields");
        String errorMsg = checkoutPage.getErrorMessage();
        Assert.assertTrue(errorMsg.contains("First Name is required"), "Wrong error: " + errorMsg);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CHECKOUT_03 PASSED: " + errorMsg);
    }

    @Test(priority = 4, description = "TC_CHECKOUT_04 - Full E2E: Login → Cart → Checkout → Confirm")
    public void testFullEndToEndFlow() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_CHECKOUT_04: Full E2E Flow");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);
        CartPage cartPage = new CartPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Login Failed");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 1: Login OK");

        String productName = homePage.getFirstProductName();
        homePage.addFirstProductToCart();
        sleep(1000);
        Assert.assertEquals(homePage.getCartCount(), 1, "Product not added");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 2: Added - " + productName);

        homePage.clickCartIcon();
        sleep(1500);
        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page not shown");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 3: Cart OK");

        cartPage.clickCheckout();
        sleep(1500);
        Assert.assertTrue(checkoutPage.isCheckoutStepOneDisplayed(), "Checkout not shown");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 4: Checkout OK");

        checkoutPage.fillCheckoutInfo("Priya", "Patel", "400001");
        sleep(800);
        checkoutPage.clickContinue();
        sleep(1500);
        Assert.assertTrue(checkoutPage.isCheckoutOverviewDisplayed(), "Overview not shown");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 5: Overview - " + checkoutPage.getTotalPriceText());

        checkoutPage.clickFinish();
        sleep(2000);
        Assert.assertTrue(checkoutPage.isOrderConfirmationDisplayed(), "Confirmation not shown");
        ExtentReportManager.getExtentTest().log(Status.INFO, "Step 6: Order placed");

        String header = checkoutPage.getConfirmationHeader();
        Assert.assertEquals(header, "Thank you for your order!", "Wrong header");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_CHECKOUT_04 PASSED: " + header);
    }
}