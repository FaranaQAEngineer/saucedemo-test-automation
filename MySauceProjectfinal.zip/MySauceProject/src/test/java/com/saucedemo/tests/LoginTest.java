package com.saucedemo.tests;

import com.aventstack.extentreports.Status;
import com.saucedemo.config.ConfigReader;
import com.saucedemo.pages.HomePage;
import com.saucedemo.pages.LoginPage;
import com.saucedemo.utils.BaseTest;
import com.saucedemo.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test(priority = 1, description = "TC_LOGIN_01 - Valid login with correct credentials")
    public void testValidLogin() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_LOGIN_01: Starting valid login test");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        loginPage.enterUsername(ConfigReader.getValidUsername());
        sleep(500);
        loginPage.enterPassword(ConfigReader.getValidPassword());
        sleep(500);
        ExtentReportManager.getExtentTest().log(Status.INFO, "Credentials entered");

        loginPage.clickLoginButton();
        sleep(1500);
        ExtentReportManager.getExtentTest().log(Status.INFO, "Login button clicked");

        boolean isHomePageDisplayed = homePage.isHomePageDisplayed();
        Assert.assertTrue(isHomePageDisplayed, "Login FAILED - Products page not shown");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_LOGIN_01 PASSED: Login successful");
    }

    @Test(priority = 2, description = "TC_LOGIN_02 - Login with wrong password")
    public void testInvalidLogin() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_LOGIN_02: Invalid login test");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterUsername(ConfigReader.getValidUsername());
        sleep(500);
        loginPage.enterPassword("wrongpassword");
        sleep(500);
        loginPage.clickLoginButton();
        sleep(1000);

        boolean errorDisplayed = loginPage.isErrorMessageDisplayed();
        Assert.assertTrue(errorDisplayed, "Error message NOT shown");

        String actualError = loginPage.getErrorMessage();
        Assert.assertTrue(actualError.contains("Username and password do not match"),
                "Wrong error: " + actualError);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_LOGIN_02 PASSED: " + actualError);
    }

    @Test(priority = 3, description = "TC_LOGIN_03 - Login with empty credentials")
    public void testEmptyCredentialsLogin() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_LOGIN_03: Empty credentials test");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.clickLoginButton();
        sleep(1000);

        boolean errorDisplayed = loginPage.isErrorMessageDisplayed();
        Assert.assertTrue(errorDisplayed, "Error NOT shown for empty credentials");

        String actualError = loginPage.getErrorMessage();
        Assert.assertTrue(actualError.contains("Username is required"),
                "Wrong error: " + actualError);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_LOGIN_03 PASSED: " + actualError);
    }

    @Test(priority = 4, description = "TC_LOGIN_04 - Login with locked out user")
    public void testLockedUserLogin() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_LOGIN_04: Locked user test");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterUsername(ConfigReader.getLockedUsername());
        sleep(500);
        loginPage.enterPassword(ConfigReader.getValidPassword());
        sleep(500);
        loginPage.clickLoginButton();
        sleep(1000);

        boolean errorDisplayed = loginPage.isErrorMessageDisplayed();
        Assert.assertTrue(errorDisplayed, "Error NOT shown for locked user");

        String actualError = loginPage.getErrorMessage();
        Assert.assertTrue(actualError.contains("locked out"), "Wrong error: " + actualError);

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_LOGIN_04 PASSED: " + actualError);
    }

    @Test(priority = 5, description = "TC_LOGIN_05 - Logout after valid login")
    public void testLogout() {
        ExtentReportManager.getExtentTest().log(Status.INFO, "TC_LOGIN_05: Logout test");

        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        sleep(1500);
        Assert.assertTrue(homePage.isHomePageDisplayed(), "Could not login");

        homePage.logout();
        sleep(1500);

        boolean isLoginPage = loginPage.isLoginPageDisplayed();
        Assert.assertTrue(isLoginPage, "Logout FAILED - Login page not shown");

        ExtentReportManager.getExtentTest().log(Status.PASS, "TC_LOGIN_05 PASSED: Logout successful");
    }
}