package com.saucedemo.utils;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.saucedemo.config.ConfigReader;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BaseTest {

    protected WebDriver driver;

    @BeforeSuite
    public void setUpSuite() {
        System.out.println("\n========================================");
        System.out.println("  SUITE STARTING - Initializing Report");
        System.out.println("========================================\n");
        ExtentReportManager.getInstance();
    }

    @BeforeMethod
    public void setUp(Method method) {
        System.out.println("\n>>> TEST STARTING: " + method.getName() + " <<<");
        System.out.println("    Opening new browser window...");

        DriverFactory.initDriver();
        driver = DriverFactory.getDriver();

        ExtentTest test = ExtentReportManager.getInstance()
                .createTest(method.getName());
        ExtentReportManager.setExtentTest(test);

        driver.get(ConfigReader.getUrl());
        System.out.println("    URL loaded: " + ConfigReader.getUrl());

        sleep(1500);

        ExtentReportManager.getExtentTest()
                .log(Status.INFO, "Launched URL: " + ConfigReader.getUrl());
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        ExtentTest test = ExtentReportManager.getExtentTest();
        String testName = result.getName();

        if (result.getStatus() == ITestResult.FAILURE) {
            String screenshotPath = captureScreenshot(testName);
            test.fail("Test FAILED: " + result.getThrowable().getMessage());
            try {
                test.addScreenCaptureFromPath(
                    new File(screenshotPath).toURI().toString(),
                    "Failure Screenshot"
                );
            } catch (Exception e) {
                test.fail("Screenshot could not be attached: " + e.getMessage());
            }
            System.out.println("    [FAIL] " + testName);

        } else if (result.getStatus() == ITestResult.SUCCESS) {
            test.pass("Test PASSED");
            System.out.println("    [PASS] " + testName);

        } else if (result.getStatus() == ITestResult.SKIP) {
            String reason = result.getThrowable() != null
                    ? result.getThrowable().getMessage() : "No reason provided";
            test.skip("Test SKIPPED: " + reason);
            System.out.println("    [SKIP] " + testName);
        }

        sleep(1000);
        DriverFactory.quitDriver();
        System.out.println("    Browser closed for: " + testName);
    }

    @AfterSuite
    public void tearDownSuite() {
        ExtentReportManager.flushReports();
        System.out.println("\n========================================");
        System.out.println("  SUITE COMPLETE - Report saved in /reports/");
        System.out.println("========================================\n");
    }

    protected void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private String captureScreenshot(String testName) {
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String screenshotDir = System.getProperty("user.dir") + "/reports/screenshots/";
        String screenshotPath = screenshotDir + testName + "_" + timestamp + ".png";

        try {
            Files.createDirectories(Paths.get(screenshotDir));
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(srcFile.toPath(), Paths.get(screenshotPath));
            System.out.println("    Screenshot saved: " + screenshotPath);
        } catch (IOException e) {
            System.err.println("    Screenshot could not be saved: " + e.getMessage());
        }
        return screenshotPath;
    }
}