package com.saucedemo.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExtentReportManager {

    private static ExtentReports extentReports;
    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    public static synchronized ExtentReports getInstance() {
        if (extentReports == null) {
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));

            String reportDir = System.getProperty("user.dir") + "/reports/";
            java.io.File dir = new java.io.File(reportDir);
            if (!dir.exists()) dir.mkdirs();

            String reportPath = reportDir + "SauceDemo_Report_" + timestamp + ".html";
            System.out.println("[ExtentReport] Report will be saved at: " + reportPath);

            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
            sparkReporter.config().setDocumentTitle("SauceDemo Automation Report");
            sparkReporter.config().setReportName("SauceDemo E2E Test Results");
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setEncoding("UTF-8");

            extentReports = new ExtentReports();
            extentReports.attachReporter(sparkReporter);

            extentReports.setSystemInfo("Project",     "SauceDemo Automation");
            extentReports.setSystemInfo("Framework",   "Selenium + TestNG + POM");
            extentReports.setSystemInfo("Browser",     "Chrome");
            extentReports.setSystemInfo("Author",      "QA Automation Engineer");
            extentReports.setSystemInfo("Environment", "https://www.saucedemo.com");
        }
        return extentReports;
    }

    public static void setExtentTest(ExtentTest test) {
        extentTest.set(test);
    }

    public static ExtentTest getExtentTest() {
        return extentTest.get();
    }

    public static synchronized void flushReports() {
        if (extentReports != null) {
            extentReports.flush();
            System.out.println("[ExtentReport] Report flushed successfully.");
        }
    }
}