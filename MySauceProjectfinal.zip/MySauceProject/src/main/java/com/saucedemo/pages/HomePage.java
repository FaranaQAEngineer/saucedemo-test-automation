package com.saucedemo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * HomePage - Page Object Model for the Products / Home Page.
 * Covers: product listing, search/filter, add to cart, logout.
 */
public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ===================== LOCATORS =====================
    private By productsTitle       = By.className("title");
    private By productItems        = By.className("inventory_item");
    private By productNames        = By.className("inventory_item_name");
    private By addToCartButtons    = By.cssSelector("[data-test^='add-to-cart']");
    private By cartIcon            = By.className("shopping_cart_link");
    private By cartBadge           = By.className("shopping_cart_badge");
    private By hamburgerMenu       = By.id("react-burger-menu-btn");
    private By logoutLink          = By.id("logout_sidebar_link");
    private By sortDropdown        = By.className("product_sort_container");
    private By filterBar           = By.className("product_sort_container");

    // ===================== CONSTRUCTOR =====================
    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ===================== ACTIONS =====================

    public boolean isHomePageDisplayed() {
        try {
            WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(productsTitle));
            return title.getText().equalsIgnoreCase("Products");
        } catch (Exception e) {
            return false;
        }
    }

    public String getPageTitle() {
        return driver.findElement(productsTitle).getText();
    }

    /**
     * Returns total number of products displayed on page.
     */
    public int getProductCount() {
        List<WebElement> items = driver.findElements(productItems);
        return items.size();
    }

    /**
     * Searches for a product by name (partial match) and returns true if found.
     */
    public boolean searchProductByName(String productName) {
        List<WebElement> names = driver.findElements(productNames);
        for (WebElement name : names) {
            if (name.getText().toLowerCase().contains(productName.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds the first product to the cart.
     */
    public void addFirstProductToCart() {
        List<WebElement> buttons = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(addToCartButtons));
        buttons.get(0).click();
    }

    /**
     * Adds a specific product to cart by product name.
     */
    public void addProductToCartByName(String productName) {
        // Build the exact data-test attribute for "add-to-cart-<product-slug>"
        String slug = productName.toLowerCase().replace(" ", "-");
        By addButton = By.cssSelector("[data-test='add-to-cart-" + slug + "']");
        wait.until(ExpectedConditions.elementToBeClickable(addButton)).click();
    }

    /**
     * Returns cart count badge number. Returns 0 if cart is empty.
     */
    public int getCartCount() {
        try {
            String count = driver.findElement(cartBadge).getText();
            return Integer.parseInt(count);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Clicks the shopping cart icon.
     */
    public void clickCartIcon() {
        wait.until(ExpectedConditions.elementToBeClickable(cartIcon)).click();
    }

    /**
     * Performs logout via hamburger menu.
     */
    public void logout() {
        wait.until(ExpectedConditions.elementToBeClickable(hamburgerMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(logoutLink)).click();
    }

    /**
     * Returns the name of the first product on the page.
     */
    public String getFirstProductName() {
        List<WebElement> names = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(productNames));
        return names.get(0).getText();
    }
}
