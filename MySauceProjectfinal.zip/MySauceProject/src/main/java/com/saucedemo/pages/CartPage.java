package com.saucedemo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * CartPage - Page Object Model for the Shopping Cart Page.
 * Covers: viewing cart items, removing items, proceeding to checkout.
 */
public class CartPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ===================== LOCATORS =====================
    private By cartTitle          = By.className("title");
    private By cartItems          = By.className("cart_item");
    private By cartItemNames      = By.className("inventory_item_name");
    private By removeButtons      = By.cssSelector("[data-test^='remove']");
    private By checkoutButton     = By.id("checkout");
    private By continueShoppingBtn = By.id("continue-shopping");

    // ===================== CONSTRUCTOR =====================
    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ===================== ACTIONS =====================

    public boolean isCartPageDisplayed() {
        try {
            WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(cartTitle));
            return title.getText().equalsIgnoreCase("Your Cart");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns number of items currently in the cart page.
     */
    public int getCartItemCount() {
        List<WebElement> items = driver.findElements(cartItems);
        return items.size();
    }

    /**
     * Returns the name of the first item in the cart.
     */
    public String getFirstCartItemName() {
        List<WebElement> names = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(cartItemNames));
        return names.get(0).getText();
    }

    /**
     * Removes the first item from the cart.
     */
    public void removeFirstItem() {
        List<WebElement> removeButtons = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(this.removeButtons));
        removeButtons.get(0).click();
    }

    /**
     * Checks if the cart is empty (no items displayed).
     */
    public boolean isCartEmpty() {
        return driver.findElements(cartItems).isEmpty();
    }

    /**
     * Clicks Checkout button to proceed to checkout.
     */
    public void clickCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
    }

    /**
     * Clicks Continue Shopping to go back to products page.
     */
    public void clickContinueShopping() {
        wait.until(ExpectedConditions.elementToBeClickable(continueShoppingBtn)).click();
    }
}
