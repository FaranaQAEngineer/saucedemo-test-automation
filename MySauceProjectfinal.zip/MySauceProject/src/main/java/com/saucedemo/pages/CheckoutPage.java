package com.saucedemo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * CheckoutPage - Page Object Model for Checkout Step One and Step Two.
 * Covers: entering shipping info, reviewing order, finishing checkout.
 */
public class CheckoutPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ===================== LOCATORS - Step One (Shipping Info) =====================
    private By checkoutTitle   = By.className("title");
    private By firstNameField  = By.id("first-name");
    private By lastNameField   = By.id("last-name");
    private By zipCodeField    = By.id("postal-code");
    private By continueButton  = By.id("continue");
    private By errorMessage    = By.cssSelector("[data-test='error']");

    // ===================== LOCATORS - Step Two (Overview) =====================
    private By overviewTitle   = By.className("title");
    private By finishButton    = By.id("finish");
    private By itemTotal       = By.className("summary_subtotal_label");
    private By tax             = By.className("summary_tax_label");
    private By totalPrice      = By.className("summary_total_label");

    // ===================== LOCATORS - Confirmation Page =====================
    private By confirmationHeader  = By.className("complete-header");
    private By confirmationText    = By.className("complete-text");
    private By backHomeButton      = By.id("back-to-products");

    // ===================== CONSTRUCTOR =====================
    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ===================== STEP ONE ACTIONS =====================

    public boolean isCheckoutStepOneDisplayed() {
        try {
            WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(checkoutTitle));
            return title.getText().equalsIgnoreCase("Checkout: Your Information");
        } catch (Exception e) {
            return false;
        }
    }

    public void enterFirstName(String firstName) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField));
        field.clear();
        field.sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        driver.findElement(lastNameField).clear();
        driver.findElement(lastNameField).sendKeys(lastName);
    }

    public void enterZipCode(String zipCode) {
        driver.findElement(zipCodeField).clear();
        driver.findElement(zipCodeField).sendKeys(zipCode);
    }

    /**
     * Fills all checkout information fields in one call.
     */
    public void fillCheckoutInfo(String firstName, String lastName, String zipCode) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterZipCode(zipCode);
    }

    public void clickContinue() {
        driver.findElement(continueButton).click();
    }

    public boolean isErrorDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public String getErrorMessage() {
        return driver.findElement(errorMessage).getText();
    }

    // ===================== STEP TWO ACTIONS =====================

    public boolean isCheckoutOverviewDisplayed() {
        try {
            WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(overviewTitle));
            return title.getText().equalsIgnoreCase("Checkout: Overview");
        } catch (Exception e) {
            return false;
        }
    }

    public String getItemTotalText() {
        return driver.findElement(itemTotal).getText();
    }

    public String getTotalPriceText() {
        return driver.findElement(totalPrice).getText();
    }

    public void clickFinish() {
        wait.until(ExpectedConditions.elementToBeClickable(finishButton)).click();
    }

    // ===================== ORDER CONFIRMATION ACTIONS =====================

    public boolean isOrderConfirmationDisplayed() {
        try {
            WebElement header = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(confirmationHeader));
            return header.getText().equalsIgnoreCase("Thank you for your order!");
        } catch (Exception e) {
            return false;
        }
    }

    public String getConfirmationHeader() {
        return driver.findElement(confirmationHeader).getText();
    }

    public String getConfirmationText() {
        return driver.findElement(confirmationText).getText();
    }

    public void clickBackToHome() {
        wait.until(ExpectedConditions.elementToBeClickable(backHomeButton)).click();
    }
}
