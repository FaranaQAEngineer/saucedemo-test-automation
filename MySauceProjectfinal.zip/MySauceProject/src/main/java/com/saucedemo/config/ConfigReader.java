package com.saucedemo.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader - Reads configuration from config.properties file
 * This avoids hardcoding values like URL, credentials, browser type.
 */
public class ConfigReader {

    private static Properties properties;
    private static final String CONFIG_PATH = "src/test/resources/config.properties";

    static {
        try {
            FileInputStream fis = new FileInputStream(CONFIG_PATH);
            properties = new Properties();
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            throw new RuntimeException("config.properties file not found at: " + CONFIG_PATH, e);
        }
    }

    public static String getUrl() {
        return properties.getProperty("url");
    }

    public static String getBrowser() {
        return properties.getProperty("browser", "chrome");
    }

    public static String getValidUsername() {
        return properties.getProperty("valid.username");
    }

    public static String getValidPassword() {
        return properties.getProperty("valid.password");
    }

    public static String getLockedUsername() {
        return properties.getProperty("locked.username");
    }

    public static String getImplicitWait() {
        return properties.getProperty("implicit.wait", "10");
    }

    public static String getPageLoadTimeout() {
        return properties.getProperty("page.load.timeout", "30");
    }
}
